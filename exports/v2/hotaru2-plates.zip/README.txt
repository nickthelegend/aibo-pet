HOTARU 2.0 -- printable plates (Bambu P1S, 256 x 256)
====================================================

v1 is deprecated. 2.0 adds the 180-degree pan base: an MG996R
dead centre in the tub drives the turntable disc; the disc
rides the tub rim, so the bearing is the rim and the servo
only ever sees torque.

Print order:
1. v2-plate-1-base.stl   214 x 213 x 68 mm
2. v2-plate-2-disc.stl   155 x 207 x 11 mm
3. v2-plate-3-head.stl   237 x 221 x 72 mm

SUPPORTS ON for: v2-head, v2-link1-in, v2-link1-out, v2-trimcap, v2-tub
(everything else prints clean -- measured by cad/v2_audit.py,
which also proves every joint engagement number on this arm)

Electronics: ESP32-S3, MAX98357A, 40x20 speaker, round mic,
3x MG996R, 1x SG90, M3 inserts -- the same BOM as v1.

CAD, audits, and the whole history:
github.com/nickthelegend/aibo-pet