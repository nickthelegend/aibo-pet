HOTARU 2.0 -- printable plates (Bambu P1S, 256 x 256)
====================================================

v1 is deprecated. 2.0 adds the 180-degree pan base: an MG996R
dead centre in the tub drives the turntable disc; the disc
rides the tub rim, so the bearing is the rim and the servo
only ever sees torque.

Print order:
1. v2-plate-1-base.stl   189 x 230 x 56 mm
2. v2-plate-3-turntable.stl   178 x 236 x 68 mm
3. v2-plate-2-arm.stl   222 x 208 x 60 mm
4. v2-plate-4-cone.stl   206 x 222 x 86 mm

SUPPORTS ON for: v2-bolts, v2-head, v2-link1-in, v2-link1-out, v2-screws, v2-tub
(everything else prints clean -- measured by cad/v2_audit.py,
which also proves every joint engagement number on this arm)

Electronics: ESP32-S3, MAX98357A, 40x20 speaker, round mic,
4x MG996R and NOTHING ELSE: every fastener is printed. P6 thumb-bolts into printed-thread sleeves, two printed yoke screws, two disc keys, locating pins under the boards.

CAD, audits, and the whole history:
github.com/nickthelegend/aibo-pet