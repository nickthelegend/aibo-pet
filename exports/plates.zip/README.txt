HOTARU -- printable plates
==============================

Bed: 180 x 180 mm (Bambu A1 mini).
Print in this order. Plate 1 is a 15 minute coupon that checks the
printed spline fits your servo BEFORE you commit to an 8 hour tub.

1. plate-1-test.stl
   print FIRST -- verifies the printed spline before you commit
   2 part(s), 118 x 48 x 7 mm
   supports: not needed

2. plate-2-base.stl
   the round tub; it owns the bed on its own
   1 part(s), 160 x 160 x 58 mm
   supports: not needed

3. plate-2b-shoulder.stl
   the shoulder ring -- goes on AFTER the electronics
   1 part(s), 160 x 158 x 33 mm
   SUPPORTS: ON  (shoulder)

4. plate-3a-arm-lower.stl
   arm segment 1 of 3 -- standing on its yoke
   1 part(s), 60 x 26 x 154 mm
   SUPPORTS: ON  (arm-lower)

5. plate-3b-arm-upper.stl
   arm segment 2 of 3 -- standing on its yoke
   1 part(s), 60 x 26 x 154 mm
   SUPPORTS: ON  (arm-upper)

6. plate-3c-arm-fore.stl
   arm segment 3 of 3 -- standing on its yoke
   1 part(s), 60 x 21 x 133 mm
   SUPPORTS: ON  (arm-fore)

7. plate-4-head.stl
   cone (mouth down) + lid (top face down)
   1 part(s), 114 x 114 x 6 mm
   supports: not needed

8. plate-4-head-2.stl
   cone (mouth down) + lid (top face down)
   1 part(s), 66 x 66 x 72 mm
   SUPPORTS: ON  (shade)

9. plate-5-small.stl
   everything that is quick
   16 part(s), 150 x 139 x 52 mm
   SUPPORTS: ON  (base-joint)

Supports are needed only where listed. Everything else prints
as modelled; measured by cad/audit_printable.py, not asserted.

CAD, STLs and audits: github.com/nickthelegend/aibo-pet